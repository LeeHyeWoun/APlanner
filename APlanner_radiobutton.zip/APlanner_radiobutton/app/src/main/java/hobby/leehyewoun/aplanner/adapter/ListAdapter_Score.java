package hobby.leehyewoun.aplanner.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.List;

import hobby.leehyewoun.aplanner.R;
import hobby.leehyewoun.aplanner.bean.SaveBean;
import hobby.leehyewoun.aplanner.bean.ScoreBean;
import hobby.leehyewoun.aplanner.util.PrefUtil;

import static android.content.Context.INPUT_METHOD_SERVICE;

public class ListAdapter_Score extends BaseAdapter {
    //생성자의 매개변수 값을 받을 변수
    private Context mContext;
    private List<ScoreBean> mList;
    private int FragmentTabOfNum;
    private ListView FragmentScoreList;

    //생성자
    public ListAdapter_Score(Context context, List<ScoreBean> list, int tabOfNum, ListView scoreList){
        mContext=context;
        mList=list;
        FragmentTabOfNum = tabOfNum;
        FragmentScoreList = scoreList;
    }

    @Override
    public int getCount() { return mList.size(); }

    @Override
    public Object getItem(int position) { return position; }

    @Override
    public long getItemId(int position) { return position; }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        //인플레이팅 하는 작업
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.view_score_list, null);

        //해당 ROW 의 데이터를 찾는 작업
        final ScoreBean scoreBean = mList.get(position);

        //인플레이팅 된 뷰에서 ID 찾는작업
        TextView txtCategory = convertView.findViewById(R.id.txtCategory);
        TextView txtScore = convertView.findViewById(R.id.txtScore);
        TextView txtCredit = convertView.findViewById(R.id.txtCredit);
        TextView txtSubject = convertView.findViewById(R.id.txtSubject);

        //데이터 설정
        txtCategory.setText(scoreBean.getCategory());
        txtScore.setText(scoreBean.getScore());
        txtCredit.setText(scoreBean.getCredit());
        txtSubject.setText(scoreBean.getSubject());

        convertView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                return false;
            }
        });

        return convertView;
    }//end OnCreate;
}
