package hobby.leehyewoun.aplanner.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import java.util.ArrayList;

import hobby.leehyewoun.aplanner.R;
import hobby.leehyewoun.aplanner.ScoreModifyActivity;
import hobby.leehyewoun.aplanner.adapter.ListAdapter_Score;
import hobby.leehyewoun.aplanner.bean.SaveBean;
import hobby.leehyewoun.aplanner.bean.ScoreBean;
import hobby.leehyewoun.aplanner.util.PrefUtil;

public class ScoreList1Fragment extends Fragment {
    //xml 의 객체
    private ListView scoreList;
    private TextView txtNoList;

    //어답터
    private ListAdapter_Score listAdapterScore;

    //Gson
    Gson gson = new Gson();

    //Bean
    private SaveBean saveBean = new SaveBean();

    //tab 위치
    private int tabOfNum;
    private String KeyName_tabData;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_score_list,null);

        //아이디 찾기
        scoreList = view.findViewById(R.id.scoreList);
        txtNoList = view.findViewById(R.id.txtNoList);

        txtNoList.setVisibility(View.GONE);

        //탭 데이터의 키값 설정
        KeyName_tabData = tabOfNum+"tabScoreData";

        txtNoList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),ScoreModifyActivity.class);
                intent.putExtra("tabOfNum",tabOfNum);
                startActivity(intent);
            }
        });

        return view;
    }//end onCreateView

    @Override
    public void onResume() {
        super.onResume();

        //기존에 저장한 리스트 불러오기
        String jsonScoreBeanData = PrefUtil.getData(getActivity(),KeyName_tabData);
        if(jsonScoreBeanData.length()>0){
            saveBean = gson.fromJson(jsonScoreBeanData,SaveBean.class);
        }
        if(saveBean.getScoreListBean()==null){
            saveBean.setScoreListBean(new ArrayList<ScoreBean>());
            txtNoList.setVisibility(View.VISIBLE);
        }

        listAdapterScore = new ListAdapter_Score(getContext(),saveBean.getScoreListBean(),tabOfNum, scoreList);
        scoreList.setAdapter(listAdapterScore);
    }//end onResume

    //tabOfNum 설정자
    public void setTabOfNum(int tabNum){
        tabOfNum = tabNum;
    }

}//end class
