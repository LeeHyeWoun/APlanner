package hobby.leehyewoun.aplanner;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.graphics.Rect;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;

import hobby.leehyewoun.aplanner.adapter.ListAdapter_ScoreModify;
import hobby.leehyewoun.aplanner.bean.SaveBean;
import hobby.leehyewoun.aplanner.bean.ScoreBean;
import hobby.leehyewoun.aplanner.util.PrefUtil;

public class ScoreModifyActivity extends AppCompatActivity {
    //xml
    private ImageView imgBack, imgSave;
    private ProgressBar creditsEarned;
    private ListView list;
    private TextView txtTitle,txtTabName, txtCreditsEarned, txtCategory, txtScore;
    private EditText edtCredit, edtSubject;
    private NumberPicker npCategory;
    private LinearLayout groupCategory, groupScore;
    private RadioGroup groupCategory1, groupCategory2, groupScore1, groupScore2;

    //어답터
    private ListAdapter_ScoreModify listAdapter;

    //Bean
    private SaveBean saveBean;

    //키보드 객체
    private InputMethodManager imm;

    //변수
    private final long FINISH_INTERVAL_TIME = 2000;     //뒤로가기 관련 변수
    private long backPressedTime = 0;                   //뒤로가기 관련 변수
    private Boolean stop =false;    //라디오버튼_setCheck 로 인한 CheckedChange 재호출 방지
    private  int tabOfNum;
    private String tabName;
    private String KeyName_tabData;
    private int listItemHeight;
    private int sumCredit;
    private float tabX;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scoremodify);

        //아이디 찾기
        imgBack = findViewById(R.id.imgBack);
        txtTitle = findViewById(R.id.txtTitle);
        imgSave = findViewById(R.id.imgSave);
        txtCreditsEarned = findViewById(R.id.txtCreditsEarned);
        creditsEarned = findViewById(R.id.creditsEarned);
        txtTabName = findViewById(R.id.txtTabName);
        list = findViewById(R.id.list);
        //리스트 추가 아이디
        txtCategory = findViewById(R.id.txtCategory);
        txtScore = findViewById(R.id.txtScore);
        edtCredit = findViewById(R.id.edtCredit);
        edtSubject = findViewById(R.id.edtSubject);
        //넘버피커
        npCategory = findViewById(R.id.npCategory);
        //라디오버튼
        groupCategory = findViewById(R.id.groupCategory);
        groupScore = findViewById(R.id.groupScore);
        groupCategory1 = findViewById(R.id.groupCategory1);
        groupCategory2 = findViewById(R.id.groupCategory2);
        groupScore1 = findViewById(R.id.groupScore1);
        groupScore2 = findViewById(R.id.groupScore2);

        //키보드 객체
        imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);

        //이수학점 설정
        sumCredit = PrefUtil.getDataInt0(ScoreModifyActivity.this,"sumCredit");
        txtCreditsEarned.setText(String.valueOf(sumCredit));
        creditsEarned.setProgress(sumCredit);

        //데이터 수신
        Intent intent = getIntent();
        tabOfNum = intent.getExtras().getInt("tabOfNum");
        tabX = intent.getExtras().getInt("tabX");

        //현재 학기에 대한 데이터 받기
        int semester = PrefUtil.getDataInt(ScoreModifyActivity.this,"semester");

        //탭이름 구하기
        //탭의 위치로 부터 탭의 이름을 구하기 위한 계산
        int count, i;
        for(i=0,count=0; i<semester && count<=tabOfNum; i++){
            //정규 학기
            if(i%2==0){ count++; }
            //계절학기
            else {
                //기존에 저장한 탭 존재여부 불러오기
                Boolean tabData = PrefUtil.getDataBoolean(ScoreModifyActivity.this,"tab"+(i+1));
                if (tabData) { count++; }
            }
        }
        //탭의 이름 설정
        tabName=(i/4+1) + "학년 ";
        if(i%2!=0){
            tabName += (i%4/2+1)+"학기"; }
        else if(i%4==2){
            tabName += "여름"; }
        else{
            tabName += "겨울"; }

        txtTabName.setText(tabName);

        //탭 데이터의 키값 설정
        KeyName_tabData = tabOfNum+"tabScoreData";

        //학기 정보 텍스트 애니메이션 탭 전의 위치에서 중앙으로
        Animation aniT = new TranslateAnimation(tabX, 0, 0, 0);
        aniT.setDuration(600);
        aniT.setInterpolator(AnimationUtils.loadInterpolator(this, android.R.anim. accelerate_decelerate_interpolator));
        txtTabName.startAnimation(aniT);

        //넘버피커 설정
        final String[] sCategory = new String[]{"전공필수","전공선택","교양필수","교양선택","복수전공필수","복수전공선택","부전공필수","부전공선택","일반선택","기타"};
        npCategory.setMinValue(0);
        npCategory.setMaxValue(9);
        npCategory.setValue(0);
        npCategory.setWrapSelectorWheel(false);
        npCategory.setDisplayedValues(sCategory);
        npCategory.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                txtCategory.setText(sCategory[newVal]);
            }
        });


        //이벤트-----------------------------------------------------------------------------------
        //titleBar
        imgBack.setOnClickListener(titleBar);
        imgSave.setOnClickListener(titleBar);
        //input_라디오버튼
        txtCategory.setOnClickListener(txtButton);
        txtScore.setOnClickListener(txtButton);
        groupCategory1.setOnCheckedChangeListener(radio);
        groupCategory2.setOnCheckedChangeListener(radio);
        groupScore1.setOnCheckedChangeListener(radio);
        groupScore2.setOnCheckedChangeListener(radio);
        //input_키보드
        edtCredit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.length()>0&&edtSubject.getText().length()==0){
                    edtSubject.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        edtCredit.setOnFocusChangeListener(edtFocus);
        edtSubject.setOnFocusChangeListener(edtFocus);

    }//end onCreate

    @Override
    protected void onResume() {
        super.onResume();

        saveBean= new SaveBean();

        //기존에 저장한 리스트 불러오기
        String jsonScoreBeanData = PrefUtil.getData(ScoreModifyActivity.this,KeyName_tabData);
        if(jsonScoreBeanData.length()>0){
            Gson gson = new Gson();
            saveBean = gson.fromJson(jsonScoreBeanData,SaveBean.class);
        }
        if(saveBean.getScoreListBean()==null){
            saveBean.setScoreListBean(new ArrayList<ScoreBean>());
        }
        listAdapter = new ListAdapter_ScoreModify(ScoreModifyActivity.this,saveBean.getScoreListBean(),txtTitle,imgSave,
                tabOfNum, txtCategory,txtScore,edtCredit,edtSubject);
        list.setAdapter(listAdapter);

        //density 구하기
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        float density = displayMetrics.density; //px = dp*density;

        //리스트의 높이
        listItemHeight = (int) (saveBean.getScoreListBean().size()*30*density*2);

    }

    //이벤트 리스너==================================================================================
    private ImageView.OnClickListener titleBar = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.imgBack:
                    finish();
                    break;

                case R.id.imgSave:
                    if(txtCategory.getText().toString().equals("")
                            &&txtScore.getText().toString().equals("")
                            &&edtCredit.getText().toString().equals("")
                            &&edtSubject.getText().toString().equals("")){
                        Toast.makeText(ScoreModifyActivity.this,"추가할 내용을 입력해주세요.",Toast.LENGTH_SHORT).show();
                    }
                    else if(txtCategory.getText().toString().equals("")
                            ||txtScore.getText().toString().equals("")
                            ||edtCredit.getText().toString().equals("")
                            ||edtSubject.getText().toString().equals("")){
                        Toast.makeText(ScoreModifyActivity.this,"내용을 전부 채워주세요.",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        int selectedListData =PrefUtil.getDataInt(ScoreModifyActivity.this,tabOfNum+"EditList");
                        Gson gson = new Gson();
                        ScoreBean scoreBean = new ScoreBean();
                        scoreBean.setCategory(txtCategory.getText().toString());
                        scoreBean.setScore(txtScore.getText().toString());
                        scoreBean.setCredit(edtCredit.getText().toString());
                        scoreBean.setSubject(edtSubject.getText().toString());
                        if(selectedListData == -1){
                            String data = gson.toJson(saveBean);
                            if(!data.contains(scoreBean.getSubject())){
                                //저장하기...리스트 마지막에 추가
                                saveBean.getScoreListBean().add(scoreBean);
                                PrefUtil.setData(ScoreModifyActivity.this,KeyName_tabData,gson.toJson(saveBean));

                                //이번학기 이수한 학점 저장
                                if(!scoreBean.getScore().equals("F")){
                                    sumCredit += Integer.parseInt(scoreBean.getCredit());
                                    PrefUtil.setData(ScoreModifyActivity.this,"sumCredit",sumCredit);
                                    txtCreditsEarned.setText(String.valueOf(sumCredit));
                                    creditsEarned.setProgress(sumCredit);
                                }

                                //안내
                                Toast.makeText(ScoreModifyActivity.this,"추가 완료",Toast.LENGTH_SHORT).show();
                            }
                            else{
                                //안내
                                Toast.makeText(ScoreModifyActivity.this,"이미 저장되어 있습니다.",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else {
                            //수정하기...이전 데이터를 삭제하고 리스트에 추가하기
                            saveBean.getScoreListBean().remove(selectedListData);
                            saveBean.getScoreListBean().add(selectedListData,scoreBean);

                            //저장 아이콘 변경
                            imgSave.setImageResource(R.drawable.icon_add);

                            //리스트 체크 해제
                            PrefUtil.setData(ScoreModifyActivity.this,tabOfNum+"EditList",-1);

                            //이수학점 수정
                            if(!saveBean.getScoreListBean().get(selectedListData).getScore().equals("F")){
                                sumCredit -= Integer.parseInt(saveBean.getScoreListBean().get(selectedListData).getCredit());
                            }
                            if(!scoreBean.getScore().equals("F")){
                                sumCredit += Integer.parseInt(scoreBean.getCredit());
                            }
                            PrefUtil.setData(ScoreModifyActivity.this,"sumCredit",sumCredit);
                            txtCreditsEarned.setText(String.valueOf(sumCredit));
                            creditsEarned.setProgress(sumCredit);

                            //타이틀 변경
                            txtTitle.setText("추가하기");

                            //안내
                            Toast.makeText(ScoreModifyActivity.this,"수정 완료",Toast.LENGTH_SHORT).show();
                        }
                        //리스트 갱신
                        listAdapter.notifyDataSetChanged();
                        //입력란 초기화
                        resetEdtLayout();
                    }
                    break;
            }
        }
    };
    private TextView.OnClickListener txtButton = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //버튼 등장 효과
            Animation animation = new AlphaAnimation(0,1);
            animation.setDuration(400);
            switch (v.getId()){
                case R.id.txtCategory:
                    groupScore.setVisibility(View.GONE);
                    //보이기
                    if(groupCategory.getVisibility()!=View.VISIBLE){
                        txtCategory.setSelected(true);
                        groupCategory.setAnimation(animation);
                        groupCategory.setVisibility(View.VISIBLE);
                        stop=false;
                    }
                    //다시 닫기
                    else {
                        txtCategory.setSelected(false);
                        groupCategory.setVisibility(View.GONE);
                    }
                    break;

                case R.id.txtScore:
                    groupCategory.setVisibility(View.GONE);
                    //보이기
                    if(groupScore.getVisibility()!=View.VISIBLE){
                        txtScore.setSelected(true);
                        groupScore.setAnimation(animation);
                        groupScore.setVisibility(View.VISIBLE);
                        stop=false;
                    }
                    //다시닫기
                    else{
                        txtScore.setSelected(false);
                        groupScore.setVisibility(View.GONE);
                    }
                    break;
            }
        }
    };
    private EditText.OnFocusChangeListener edtFocus = new View.OnFocusChangeListener() {
        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            if(!hasFocus){
                //포커스를 잃을 경우 키보드 닫기
                switch (v.getId()){
                    case R.id.edtCredit:
                        imm.hideSoftInputFromWindow(edtCredit.getWindowToken(), 0);
                        break;

                    case R.id.edtSubject:
                        imm.hideSoftInputFromWindow(edtSubject.getWindowToken(), 0);
                        break;
                }
            }
            else {
                if(v.getId()==R.id.edtCredit){
                    edtCredit.setText("");
                    imm.showSoftInput(edtCredit,0);
                }
                else {
                    imm.showSoftInput(edtSubject,0);
                }
            }
        }
    };
    private RadioGroup.OnCheckedChangeListener radio = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if(!stop){
                RadioButton rb2 = null;
                RadioButton rb = findViewById(checkedId);
                rb.setChecked(true);
                switch (group.getId()){
                    case R.id.groupCategory1:
                        txtCategory.setText(rb.getText());
                        txtCategory.setSelected(false);
                        groupCategory.setVisibility(View.GONE);
                        if(txtScore.getText().equals("")){
                            txtScore.setSelected(true);
                            //버튼 등장 효과
                            Animation animation = new AlphaAnimation(0,1);
                            animation.setDuration(400);
                            groupScore.setAnimation(animation);
                            groupScore.setVisibility(View.VISIBLE);
                        }
                        rb2 = findViewById(groupCategory2.getCheckedRadioButtonId());
                        break;

                    case R.id.groupCategory2:
                        txtCategory.setText(rb.getText());
                        txtCategory.setSelected(false);
                        groupCategory.setVisibility(View.GONE);
                        if(txtScore.getText().equals("")){
                            txtScore.setSelected(true);
                            //버튼 등장 효과
                            Animation animation = new AlphaAnimation(0,1);
                            animation.setDuration(400);
                            groupScore.setAnimation(animation);
                            groupScore.setVisibility(View.VISIBLE);
                        }
                        rb2 = findViewById(groupCategory1.getCheckedRadioButtonId());
                        break;

                    case R.id.groupScore1:
                        txtScore.setText(rb.getText());
                        txtScore.setSelected(false);
                        groupScore.setVisibility(View.GONE);
                        if(edtCredit.getText().toString().equals("")){
                            edtCredit.requestFocus();
                        }
                        rb2 = findViewById(groupScore2.getCheckedRadioButtonId());
                        break;

                    case R.id.groupScore2:
                        txtScore.setText(rb.getText());
                        txtScore.setSelected(false);
                        groupScore.setVisibility(View.GONE);
                        if(edtCredit.getText().toString().equals("")){
                            edtCredit.requestFocus();
                        }
                        rb2 = findViewById(groupScore1.getCheckedRadioButtonId());
                        break;
                }
                if(rb2!=null&&rb2.isChecked()){
                    stop=true;
                    rb2.setChecked(false);
                }
            }
            else {
                stop =false;
            }
        }
    };

    //일반 함수=====================================================================================
    private void resetEdtLayout(){
        txtCategory.setText("");
        txtScore.setText("");
        edtCredit.setText("");
        edtSubject.setText("");
    }
    //오버라이드====================================================================================
//    @Override
//    public boolean dispatchTouchEvent(MotionEvent ev) {
//        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
//            View view = getCurrentFocus();
//            //범위 외 터치 시
//            // 카테고리 라디오 그룹 닫기
//            if(groupCategory.getVisibility()==View.VISIBLE){
//                Rect r1 = new Rect();
//                Rect r2 = new Rect();
//                txtCategory.getGlobalVisibleRect(r1);
//                groupCategory.getGlobalVisibleRect(r2);
//                int rawX = (int)ev.getRawX();
//                int rawY = (int)ev.getRawY();
//                if (!r1.contains(rawX, rawY)
//                        && !r2.contains(rawX, rawY)) {
//                    txtCategory.setSelected(false);
//                    groupCategory.setVisibility(View.GONE);
//                }
//            }
//            //점수 라디로 그룹 닫기
//            else if (groupScore.getVisibility()==View.VISIBLE){
//                Rect r1 = new Rect();
//                Rect r2 = new Rect();
//                txtScore.getGlobalVisibleRect(r1);
//                groupScore.getGlobalVisibleRect(r2);
//                int rawX = (int)ev.getRawX();
//                int rawY = (int)ev.getRawY();
//                if (!r1.contains(rawX, rawY)
//                        && !r2.contains(rawX, rawY)) {
//                    txtScore.setSelected(false);
//                    groupScore.setVisibility(View.GONE);
//                }
//            }
//            //키보드 닫기
//            else if (view instanceof EditText) {
//                Rect r1 = new Rect();
//                Rect r2 = new Rect();
//                edtCredit.getGlobalVisibleRect(r1);
//                edtSubject.getGlobalVisibleRect(r2);
//                int rawX = (int)ev.getRawX();
//                int rawY = (int)ev.getRawY();
//                if (!r1.contains(rawX, rawY) && !r2.contains(rawX, rawY)) {
//                    view.clearFocus();
//                }
//            }
//            //편집 취소
//            else if(PrefUtil.getDataInt(ScoreModifyActivity.this,tabOfNum+"EditList")>-1) {
//                Rect r1 = new Rect(list.getLeft(),list.getTop(),list.getRight(),list.getTop()+listItemHeight);
//                Rect r2 = new Rect();
//                Rect r3 = new Rect();
//                Rect r4 = new Rect();
//                findViewById(R.id.edtLayout).getGlobalVisibleRect(r2);
//                imgBack.getGlobalVisibleRect(r3);
//                imgSave.getGlobalVisibleRect(r4);
//                int rawX = (int)ev.getRawX();
//                int rawY = (int)ev.getRawY();
//                if (!r1.contains(rawX, rawY)&&!r2.contains(rawX,rawY)&&!r3.contains(rawX,rawY)&&!r4.contains(rawX,rawY)) {
//                    if(!txtCategory.getText().equals("")
//                            &&!txtScore.getText().equals("")
//                            &&!edtCredit.getText().toString().equals("")
//                            &&!edtSubject.getText().toString().equals("")){
//                        //타이틀 변경
//                        txtTitle.setText("추가하기");
//                        //저장 아이콘 변경
//                        imgSave.setImageResource(R.drawable.icon_add);
//                        //리스트 체크 해제
//                        PrefUtil.setData(ScoreModifyActivity.this,tabOfNum+"EditList",-1);
//                        listAdapter.notifyDataSetChanged();
//                        //입력란 초기화
//                        resetEdtLayout();
//                        //안내
//                        Toast.makeText(ScoreModifyActivity.this,"수정 취소",Toast.LENGTH_SHORT).show();
//
//                    }
//                }
//            }
//        }
//        return super.dispatchTouchEvent(ev);
//    }
    @Override
    public void onBackPressed() {
        long tempTime = System.currentTimeMillis();
        long intervalTime = tempTime - backPressedTime;

        if (0 <= intervalTime && FINISH_INTERVAL_TIME >= intervalTime) {
            super.onBackPressed();
        }
        else {
            backPressedTime = tempTime;
            Toast.makeText(getApplicationContext(), "'뒤로'버튼을 한번 더 누르시면 수정종료됩니다.", Toast.LENGTH_SHORT).show();
        }
    }
}
