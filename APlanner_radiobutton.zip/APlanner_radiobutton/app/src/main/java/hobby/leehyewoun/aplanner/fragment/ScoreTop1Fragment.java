package hobby.leehyewoun.aplanner.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import hobby.leehyewoun.aplanner.R;
import hobby.leehyewoun.aplanner.util.PrefUtil;

public class ScoreTop1Fragment extends Fragment {

    private ProgressBar PbThisSemester,PbTotal,PbCreditsEarned;
    private TextView txtCreditsEarned;

    //변수
    private int semester;       //현재 학기 정보
    private int creditsEarned=0;  //총 이수 학점

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_score_top1,null);

        //아이디 찾기
        PbThisSemester = view.findViewById(R.id.thisSemester);
        PbTotal = view.findViewById(R.id.Total);
        PbCreditsEarned = view.findViewById(R.id.creditsEarned);
        txtCreditsEarned = view.findViewById(R.id.txtCreditsEarned);

        //현재 학기 정보 불러오기
        semester = PrefUtil.getDataInt(getActivity(),"semester");
        creditsEarned = PrefUtil.getDataInt0(getActivity(),"sumCredit");

        //총 이수 학점 설정
        PbCreditsEarned.setProgress(creditsEarned);
        txtCreditsEarned.setText(String.valueOf(creditsEarned));

        return view;
    }
}

